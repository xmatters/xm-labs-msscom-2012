importPackage(java.lang);
importPackage(java.util);
importPackage(java.io);
importPackage(java.text);

load("integrationservices/msscom/configuration.js");
load("lib/integrationservices/javascript/event.js");

var SCOMexec = "integrationservices\\msscom\\bin\\xMattersSCOM2012.exe";

function apia_event(form)
{
	IALOG.info(JSON.stringify(form, null, 2));

	var alertId = form.properties.alert_id;

	if (form.properties.action == "del")
	{
		IALOG.debug("Terminating event with alert_id: " + alertId);
		terminateEventByProperty("alert_id", alertId);
		return null;
	}
	else
	{
		var password = XMIO.decryptFile( SCOM_PASSWORD );
	  
		// Configure recipients
		var target = form.properties.notification_recipient;
		var recipients = [];
		recipients.push({'id': target, 'recipientType' : 'GROUP'}); //Syntax to add a group
		form.recipients = recipients;

		//cleanup unused properties
		delete form.properties.action;
		
		//convert fyi to string
		form.properties.fyi = form.properties.fyi.toString();
		//convert numeric values to text for display
		// set severity to be readable
		if (form.properties.severity.equals("2"))
		{
			form.properties.severity_description = "Critical";
		}
		else if (form.properties.severity.equals("1"))
		{
			form.properties.severity_description = "Warning";
		}
		else if (form.properties.severity.equals("0"))
		{
			form.properties.severity_description = "Information";
		}

		// set priority to be readable
		if (form.properties.priority.equals("2"))
		{
			form.properties.priority_description = "High";
			form.priority = "HIGH";
		}
		else if (form.properties.priority.equals("1"))
		{
			form.properties.priority_description = "Medium";
			form.priority = "MEDIUM";
		}
		else if (form.properties.priority.equals("0"))
		{
			form.properties.priority_description = "Low";
			form.priority = "LOW";
		}

		// set resolution state to be readable
		if (form.properties.resolution_state.equals("0"))
		{
			form.properties.resolution_state_description = "New";
		}
		else if (form.properties.resolution_state.equals(acknowledgedResolutionStateID.toString()))
		{
			form.properties.resolution_state_description = "Acknowledged";
		}
		else if (form.properties.resolution_state.equals(workInProgressResolutionStateID.toString()))
		{
			form.properties.resolution_state_description = "Work In Progress";
		}
		else if (form.properties.resolution_state.equals(sentToxMattersResolutionStateID.toString()))
		{
			form.properties.resolution_state_description = "Sent To xMatters";
		}
		else if (form.properties.resolution_state.equals(closeResolutionStateID.toString()))
		{
			form.properties.resolution_state_description = "Closed";
		}

		IALOG.info("\tSending GetAlertProperty request to MSSCOM...");
		// Jira SCO-1: Get the alert description from the executable and add it to the JSON payload.
		// getAlertProperty will grab the value of the specified property, which must be
		// specified immediately after getAlertProperty, and insert it into the JSON payload message.
		// Internally getAlertProperty uses reflection, hence the specified property name must
		// match a SCOM MonitoringAlert property. For a list of MonitoringAlert property see
		// http://msdn.microsoft.com/en-us/library/microsoft.enterprisemanagement.monitoring.monitoringalert.aspx
		var commandList = [
				"cmd",
				"/c",
				SCOMexec,
				"\"" + debugLogging + "\"",
				"\"" + simpleLogin + "\"",
				"\"" + serverName + "\"",
				"\"" + domain + "\"",
				"\"" + userName + "\"",
				"\"" + password + "\"",
				"\"" + alertId + "\"",
				"\"getAlertProperty\"",
				"\"Description\""
				];
		
		IALOG.info("form contents before sending getAlertProperty request to SCOM: " + JSON.stringify(form, null, 2));
		var alertDescription;
		alertDescription = execute(commandList);
		IALOG.debug("alertDescription provided by SCOM: " + alertDescription);
		if (alertDescription && alertDescription != null && alertDescription != "")
		{
			form.properties.event_description = new String(alertDescription);
		}
		IALOG.debug("form contents after sending getAlertProperty request to SCOM: " + JSON.stringify(form, null, 2));

		IALOG.debug("\tSending updateResolutionStatus request to MSSCOM with comment -Alert sent to xMatters.-...");
		// Update the SCOM Alert to set the Resolution State to be xMatters Delivered
		commandList = [
				"cmd",
				"/c",
				SCOMexec,
				"\"" + debugLogging + "\"",
				"\"" + simpleLogin + "\"",
				"\"" + serverName + "\"",
				"\"" + domain + "\"",
				"\"" + userName + "\"",
				"\"" + password + "\"",
				"\"" + alertId + "\"",
				"\"updateResolutionState\"",
				"\"" + historyCommentPrefix + "Alert sent to xMatters.\"",
				"\"" + sentToxMattersResolutionStateID + "\""
				];
		execute(commandList);

		return form;
	}
}

function apia_callback(msg)
{
	var str = "Received message from xMatters:\n";
	str += "Incident: " + msg.incident_id;
	str += "\nEvent Id: " + msg.eventidentifier;
	str += "\nCallback Type: " + msg.xmatters_callback_type;
	IALOG.info(str);

	IALOG.debug("ENTER - apia_callback");

	// APClient.bin injection has been converted to a JavaScript object
	// that can be serialized and sent to xMatters.
	IALOG.info(JSON.stringify(msg, null, 2));

	if (msg.xmatters_callback_type == "status")
	{
		handleStatusCallback(msg)
	}
	else if (msg.xmatters_callback_type == "response")
	{
		handleResponseCallback(msg)
	}
	else if (msg.xmatters_callback_type == "deliveryStatus")
	{
		handleDeliveryStatusCallback(msg)
	}
	else
	{
		IALOG.error("Unknown or unspecified callback type: " + msg.xmatters_callback_type);
	}
	IALOG.debug("EXIT - apia_callback");
}

/**
 * -----------------------------------------------------------------------------
 * handleStatusCallback
 *
 * Handles the Status Callback. The status callback is returned for all event
 * updates.
 *
 * -----------------------------------------------------------------------------
 */
function handleStatusCallback(msg)
{
	IALOG.debug("Enter - handleStatusCallback for event [" + msg.eventidentifier + "]");

	var alertId = msg.additionalTokens.alert_id;
	var password = XMIO.decryptFile( SCOM_PASSWORD );
	var annotation = "xMatters event ID " + msg.eventidentifier + " for MSSCOM event [" + msg.additionalTokens.alert_id + "] has an updated Status of " + msg.status + " at " + msg.date;

	var commandList = [
		"cmd",
		"/c",
		SCOMexec,
		"\"" + debugLogging + "\"",
		"\"" + simpleLogin + "\"",
		"\"" + serverName + "\"",
		"\"" + domain + "\"",
		"\"" + userName + "\"",
		"\"" + password + "\"",
		"\"" + alertId + "\"",
		"\"annotate\"",
		"\"" + notePrefix + annotation + "\""
		];

	IALOG.debug("EXECUTE: " + JSON.stringify(commandList, null, 2));
	execute(commandList);

	IALOG.debug("Exit - handleStatusCallback");
}

/**
 * -----------------------------------------------------------------------------
 * handleDeliveryStatusCallback
 *
 * Handles the Delivery Status Callback. The delivery status callback is returned
 * when the notification deliveries are processed.
 *
 * -----------------------------------------------------------------------------
 */
function handleDeliveryStatusCallback(msg)
{
	IALOG.debug("Enter - handleDeliveryStatusCallback for event [" + msg.eventidentifier + "]");

	var alertId = msg.additionalTokens.alert_id;
	var deliveryStatus = msg.deliverystatus;
	var responder = msg.recipient;
	var responderDevice = msg.device;
	
	var password = XMIO.decryptFile( SCOM_PASSWORD );

	var message = "";
	if (msg.message != null && msg.message != "" && msg.message != "null")
	{
		message = " - " + msg.message;
	}
	var annotation = deliveryStatus + " to " + responder + "|" + responderDevice + message;

	var commandList = [
		"cmd",
		"/c",
		SCOMexec,
		"\"" + debugLogging + "\"",
		"\"" + simpleLogin + "\"",
		"\"" + serverName + "\"",
		"\"" + domain + "\"",
		"\"" + userName + "\"",
		"\"" + password + "\"",
		"\"" + alertId + "\"",
		"\"annotate\"",
		"\"" + notePrefix + annotation + "\""
		];

	IALOG.debug("EXECUTE: " + JSON.stringify(commandList, null, 2));
	execute(commandList);

	IALOG.debug("Exit - handleDeliveryStatusCallback");
}

/**
 * -----------------------------------------------------------------------------
 * handleResponseCallback
 *
 * Handles the Response Callback. The response callback is returned when the
 * event receives a response.
 *
 * -----------------------------------------------------------------------------
 */
function handleResponseCallback(msg)
{
	IALOG.debug("Enter - handleResponseCallback for event [" + msg.eventidentifier + "]");

	var response = msg.response;
	var alertId = msg.additionalTokens.alert_id;
	var responder = msg.recipient;
	var responderDevice = msg.device;

	var password = XMIO.decryptFile( SCOM_PASSWORD );

	var annotation = notePrefix + "Received response | " + response + " | ";
	// check to see if there is a user annotation to the response and add it
	if (msg.annotation != null && msg.annotation != "" && msg.annotation != "null")
	{
		annotation += msg.annotation + " | ";
	}
	annotation += responder + "|" + responderDevice;

	//setup SCOM update command
	var commandList = [
		"cmd",
		"/c",
		SCOMexec,
		"\"" + debugLogging + "\"",
		"\"" + simpleLogin + "\"",
		"\"" + serverName + "\"",
		"\"" + domain + "\"",
		"\"" + userName + "\"",
		"\"" + password + "\"",
		"\"" + alertId + "\"",
		];

	if (response.toLowerCase() == "acknowledge")
	{
		if (responder)
		{
			commandList = commandList.concat([
				"\"updateResolutionState\"",
				"\"" + annotation + "\"",
				"\"" + acknowledgedResolutionStateID + "\"",
				"\"" + responder + "\""
				]);
			execute(commandList);
		}
		else
		{
			IALOG.error("Agent Client: msscom - Request Script Failed for (" + responseAction + "/" + alertId + "): No User Specified to Own the Incident.");
		}
	}
	else if (response.toLowerCase() == "close")
	{
		commandList = commandList.concat([
			"\"updateResolutionState\"",
			"\"" + annotation + "\"",
			"\"" + closeResolutionStateID + "\""
			]);
		execute(commandList);
	}
	else if (response.toLowerCase() == "ignore")
	{
		commandList = commandList.concat([
			"\"annotate\"",
			"\"" + annotation + "\""
			]);
		execute(commandList);
	}
	else if (response.toLowerCase() == "work in progress")
	{
		if (responder)
		{
			commandList = commandList.concat([
				"\"updateResolutionState\"",
				"\"" + annotation + "\"",
				"\"" + workInProgressResolutionStateID + "\"",
				"\"" + responder + "\""
				]);
			execute(commandList);
		}
		else
		{
			IALOG.error("SCOM update failed for (" + response + "/" + alertId + "): No User Specified to Own the Incident.");
		}
	}
	else
	{
		IALOG.error("SCOM update failed for (" + alertId + "): Unknown response | " + response);
	}
	IALOG.debug("Exit - handleResponseCallback");
}

/**
 * ---------------------------------------------------------------------------------------------------------------------
 * terminateEventByProperty
 *
 * Terminates event by property key/value
 *
 * @input field name, field value
 * @return null
 * ---------------------------------------------------------------------------------------------------------------------
 */
function terminateEventByProperty(fieldName, fieldValue)
{
	IALOG.debug("Entering terminateEventByProperty() with alert_id: " + fieldValue);
	try
	{
		//get event by property value
		IALOG.debug("\tGetting ACTIVE events...");
		var urlSplit = WEB_SERVICE_URL.split("/api/");
		var xmBaseUrl = urlSplit[0];
		var response = XMIO.get(xmBaseUrl + EVENTS_API + "?status=ACTIVE&propertyName=" + encodeURIComponent(fieldName) + "%23en&propertyValue=" + encodeURIComponent(fieldValue));
		IALOG.debug("\tXMIO.get returned response.body: " + response.body);
		IALOG.debug("\tURL: " + xmBaseUrl + EVENTS_API + "?status=ACTIVE&propertyName=" + encodeURIComponent(fieldName) + "%23en&propertyValue=" + encodeURIComponent(fieldValue));
		var responseBody = JSON.parse(response.body);
		
		if ( responseBody.total === 1 )
		{			
			IALOG.info("terminateEventByProperty - Found record for termination!");
						
			//create payload for event termination
			var terminatePayload = {};
			terminatePayload.id = responseBody.data[0].id;
			terminatePayload.status = "TERMINATED";
			//POST event termination
			IALOG.debug("terminateEventByProperty - POST to URL: " + xmBaseUrl + EVENTS_API + " | with payload: " + JSON.stringify(terminatePayload));
			
			//terminate event
			response = XMIO.post(JSON.stringify(terminatePayload), xmBaseUrl + EVENTS_API);
			
			if ( response.status >= 200 && response.status <= 299 )
			{
				IALOG.info("\tterminateEventByProperty - Event associated with '" + fieldName + "' = '" + fieldValue + "' has been terminated.");
			}
			else
			{
				IALOG.info("\tterminateEventByProperty - Event associated with '" + fieldName + "' = '" + fieldValue + "' has failed to terminate.");
				IALOG.info("\tterminateEventByProperty - response.status: " + response.status.toString());
			}
			IALOG.debug("terminateEventByProperty - XMIO.post received response.body: " + response.body);
		}
		else if ( responseBody.total === 0 )
		{
			IALOG.info("\tterminateEventByProperty - No event found for termination.");
		}
		else
		{
			IALOG.info("\tterminateEventByProperty - Multiple matches found, unable to identify a record for termination.");
		}
	}
	catch (err)
	{
		IALOG.error("terminateEventByProperty - Error querying xMOD for '" + fieldName + "': " + fieldValue + " (message): " + err.message);
		IALOG.error("terminateEventByProperty - Error querying xMOD for '" + fieldName + "': " + fieldValue + " (stack): " + err.stack);
	}
	IALOG.debug("Exiting terminateEventByProperty().");
}

/**
 * This method returns the output produced by executing the specified command.
 *
 * This execute performs the exec of the command.  After doing this it performs a while loop to read
 * the input and error streams.  This is done so that the process does not hang while trying to use process.waitFor().
 * The SCOM 2012 C# program can send information to the output which can fill the buffer causing the process to hang.  
 * We continuously poll the process to read the streams so this does not occur.  This should prevent the instance from timing out.
 * If an error is created it is logged to the IA logs with a log level of ERROR.
 *
 * @param cmd - the command to execute
 *
 * @throws SecurityException - If a security manager exists and its checkExec method doesn't allow creation of the subprocess 
 * @throws IOException - If an I/O error occurs
 * @throws NullPointerException - If command is null
 * @throws IllegalArgumentException - If command is empty
 * @throws RuntimeException - If executing command results in a non-0 exit value
 *
 * @return a non-null String
 */
function execute(cmd) 
{
	IALOG.info("\tEntering execute() - calling MSSCOM with command: " + cmd);
	// Store output in a string buffer.
	var buf = new StringWriter();
	var writer = new BufferedWriter(buf);	
	var errorBuf = new StringWriter();
	var errorWriter = new BufferedWriter(errorBuf);
  
	try
	{
		// Start the process.
		var process = Runtime.getRuntime().exec(cmd);
		var inputStream = process.getInputStream();
		var errorStream = process.getErrorStream();
		var finished = false;  // Set to true when p is finished
		var exitValue;
		while( !finished)
		{
			try
			{
				// add the stream information into the buffer
				while( inputStream.available() > 0)
				{
					// put the output into the buffer
					var c = new Character( inputStream.read());
					writer.write( c);
				}
				while( errorStream.available() > 0)
				{
					// put the output into the buffer
					var c = new Character( errorStream.read());
					errorWriter.write( c);
				}
				// Ask the process for its exitValue.  If the process
				// is not finished, an IllegalThreadStateException
				// is thrown.  If it is finished, we fall through and
				// the variable finished is set to true.
				exitValue = process.exitValue();
				finished = true;
			}
			catch (e)
			{  // we only want to focus on IllegalThreadStateException, otherwise throw others
				if (e.javaException instanceof java.lang.IllegalThreadStateException) {
				// Sleep a little to save on CPU cycles
				Thread.currentThread().sleep(500);
				}
				else
				{
				throw e;
				}
			}
		}

		// Get the output of the writer.
		writer.flush();
		errorWriter.flush();
	
		if (exitValue == 0)
		{
			IALOG.debug("The following command finished correctly: " + cmd);
			IALOG.debug("The output of the command was: " + buf.toString());
		}
		else
		{
			IALOG.error("The following command had an error: " + cmd);
			IALOG.error("The output of the error is: " + errorBuf.toString());
		}
	}
	catch (ex)
	{
		IALOG.error("An exception occurred.");
		IALOG.error(ex);
	}
	finally 
	{
		try
		{
			writer.close();
		}
		catch (ex) 
		{
			IALOG.error("Exception occurred while closing buffered writer: ");
			IALOG.error(ex);
		}
		try
		{
			errorWriter.close();
		}
		catch (ex) 
		{
			IALOG.error("Exception occurred while closing buffered error writer: ");
			IALOG.error(ex);
		}
	}  
	IALOG.info("\tExiting execute().");
	return buf.toString();
}

String.prototype.toProperCase = function(){
	return String(this).toLowerCase().replace("_", " ").replace(/(^[a-z]| [a-z])/g, 
		function($1){
			return $1.toUpperCase();
		}
    );
};
