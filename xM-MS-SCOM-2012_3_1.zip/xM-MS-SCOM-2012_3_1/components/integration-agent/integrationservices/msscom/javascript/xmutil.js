XMUtil = {};

var CALLBACKS;
var DEDUPLICATION_FILTER_NAME;

(function(){
	XMUtil.deduplicate = function(data, filter) {
		var dedupFilter = DEDUPLICATION_FILTER_NAME;
		if (filter) {
			dedupFilter = filter;
		}
		
		var apxml = data, apxmlMsg = true;
		if (data instanceof Object) {
			apxmlMsg = false;
			apxml = ServiceAPI.createAPXML();
			Object.keys(data).forEach(function(el){
				apxml.setToken(el, JSON.stringify(data[el]));
			});		
		}

		if (APXML.dedup(apxml, dedupFilter)) {
			if (apxmlMsg) {
			    IALOG.warn(
				    "An event with tokens {0} has been injected into the {1} event domain "  +
					"more frequently than allowed by the deduplication filter {2}. It has been suppressed.",
					APXML.toString(apxml),
					apxml.getValue("agent_client_id"),
					dedupFilter
					);			
			}
			else {
			    IALOG.warn(
				    "An event with properties {0} has been injected into the {1} service "  +
					"more frequently than allowed by the deduplication filter {2}. It has been suppressed.",
					JSON.stringify(data, null, 2),
					ServiceAPI.getConfiguration().getName(),
					dedupFilter
					);
			}
			return true;
		}
		return false
	};
	
	XMUtil.createEventTemplate = function(callbacks, integrationservice) {
		var config = ServiceAPI.getConfiguration(),
		    cb = CALLBACKS,
		    event = {},
		    is;
		
		if (callbacks) {
			cb = callbacks;
		}
		
		if (integrationservice) {
			is = integrationservice;
		}
		else {
			is = String(config.getName());
		}
		
		if (cb) {
			var iaId = String(config.getAgentId());
			event.callbacks = [];
			for (i in cb) {
				event.callbacks[i] = {
				    'url' : 'ia://' + is,
				    'type': cb[i],
				    'iaId': iaId
				}
			}		    
		}
		return event;
	};
	
	XMUtil.parseXML = function(string) {
	    string = "" + string;
	    string = string.replace(/<\?(.*?)\?>/g,'');
	    return new XML(string.trim());
	}	
})();