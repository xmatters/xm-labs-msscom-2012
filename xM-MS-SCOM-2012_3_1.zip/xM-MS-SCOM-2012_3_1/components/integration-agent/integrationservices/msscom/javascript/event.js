load("integrationservices/applications/msscom/javascript/log.js");
load("integrationservices/applications/msscom/javascript/xmutil.js");
load("integrationservices/applications/msscom/javascript/apxml.js");
load("integrationservices/applications/msscom/javascript/xmio.js");

function apia_input(apxml)
{
	if (XMUtil.deduplicate(apxml)) {
		return;
	}

	var eventObj = XMUtil.createEventTemplate();
    var newKeys = (typeof apia_remapped_data === 'function') ? apia_remapped_data() : null;
	var incident_id = apxml.getValue("incident_id");
	incident_id = incident_id.toString().replace("{", "");
	incident_id = incident_id.toString().replace("}", "");
	apxml.setToken("incident_id", incident_id);
	
    var apxmlAsObj = APXML.toEventJs(apxml, eventObj, newKeys);
    IALOG.info("Calling JavaScript method apia_event");
    var obj = apia_event(apxmlAsObj);
    if (obj) {
	    XMIO.post(JSON.stringify(obj));
    }
}

function apia_response(apxml) {
    IALOG.info("Calling JavaScript method apia_callback");
    var apxmlAsObj = APXML.toResponseJs(apxml);
    var obj = apia_callback(apxmlAsObj);
}