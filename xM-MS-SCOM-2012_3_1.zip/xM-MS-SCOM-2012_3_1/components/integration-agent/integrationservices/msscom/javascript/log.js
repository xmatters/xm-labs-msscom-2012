IALOG = {};

(function(){
  function concat()
  {
    if (arguments.length === 1)
    {
      return arguments[0];
    }
	
    return Array.prototype.reduce.call(arguments, function(str, cur, i) {
		return str.replace("{"+(i-1)+"}", cur);
	});
  }
  
  IALOG.trace = function() 
  {
	if (ServiceAPI.getLogger().isTraceEnabled())
    {
	  var s = concat.apply(this, arguments);
      ServiceAPI.getLogger().trace(s);
    }
  };  
  
  IALOG.debug = function() 
  {
	if (ServiceAPI.getLogger().isDebugEnabled())
    {
	  var s = concat.apply(this, arguments);
      ServiceAPI.getLogger().debug(s);
    }
  };

  IALOG.info = function() 
  {
    if (ServiceAPI.getLogger().isInfoEnabled())
    {
      var s = concat.apply(this, arguments);
      ServiceAPI.getLogger().info(s);
    }
  };

  IALOG.warn = function() 
  {
    var s = concat.apply(this, arguments);
    ServiceAPI.getLogger().warn(s);
  };

  IALOG.error = function() 
  {
    var s = concat.apply(this, arguments);
    ServiceAPI.getLogger().error(s);
  };
  
  IALOG.isDebugEnabled = function()
  {
    return ServiceAPI.getLogger().isDebugEnabled();
  };
})();

