// ----------------------------------------------------------------------------------------------------
// Configuration settings for an xMatters Relevance Engine Integration
// ----------------------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------------------
// The IB Inbound Integration URL that will be used to inject events into xMatters.
// ----------------------------------------------------------------------------------------------------
WEB_SERVICE_URL = "Paste the IB Inbound Integration URL here";

EVENTS_API = "/api/xm/1/events";

// ----------------------------------------------------------------------------------------------------
// The username used to authenticate the request to xMatters.
// The user's password should be encrypted using the iapassword.sh utility.
// Please see the integration agent documentation for instructions.
// ----------------------------------------------------------------------------------------------------
var INITIATOR = "REST API UserName Here";
//Create the password file using the following command and copy the file created from the 
//IA Home directory <IAHOME>/bin/iapassword.bat --new NEW_PASSWORD_HERE --file conf/.initiatorpasswd
var PASSWORD = "conf/.initiatorpasswd";  // Password file which stores the password of the xMOD REST API user that is creating/terminating events

// deduplicator filter name
var DEDUPLICATOR_FILTER = "msscom";

// The following are configuration variables to be used for the SCOM integration
var acknowledgedResolutionStateID = 101;  // The ResolutionState ID used when Acknowledging a Alert from xMatters
var workInProgressResolutionStateID = 102;  // The ResolutionState ID used when setting Work In Progress for an Alert from xMatters
var sentToxMattersResolutionStateID = 103;  // The ResolutionState ID used when the Alert is sent to xMatters
var closeResolutionStateID = 255;  // The ResolutionState ID used when the Alert is Closed

var historyCommentPrefix = "[xMatters] ";  // The Prefix which is added to the history comments for xMatters 
var notePrefix = "[xMatters] - "; // The Prefix which is added to the note comments e.g. "[xMatters] - "

var userName = "xMatters SCOM UserName here";  // Username of the user that is accessing the Alert, changing the status and updating Alerts
//Create the password file using the following command and copy the file created from the 
//IA Home directory <IAHOME>/bin/iapassword.bat --new NEW_PASSWORD_HERE --file conf/.msscompasswd
var SCOM_PASSWORD = "conf/.msscompasswd";  // Password file which stores the password of the user that is accessing the Alert, changing the status and updating Alerts

var simpleLogin = false;  // Simple login will only use the serverName to create a connection to the Microsoft Enterprise Management Group
var serverName = "localhost";  // Server name for the server running SCOM
var domain = "domain";  // Domain on which the server is running where the Alerts will be queried from.
var debugLogging = false;  // When set to true, debug logging information will be logged though the xMattersSCOM2012.exe into log/AlarmPointSCOMIntegrationLog.txt.
